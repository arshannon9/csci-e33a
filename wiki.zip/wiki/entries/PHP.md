# PHP

PHP is a general-purpose scripting language geared towards web development.

# JavaScript

JavaScript, often abbreviated as JS, is a programming language that is one of the core technologies of the __World Wide Web__, alongside [HTML](/wiki/HTML) and [CSS](/wiki/CSS).